import type { NextApiRequest, NextApiResponse } from 'next'
import { Configuration, OpenAIApi } from 'openai';

const configuration = new Configuration({
  apiKey: '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',
});
const openai = new OpenAIApi(configuration);


type Data = {
  success: boolean,
  message: string,
  data?: (string | undefined)[]
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  switch (req.method){
    case 'POST':
      if (req.body && req.body.text) {
        const content = `\"${req.body.text}\" Enhance the text for tweet`
        try {
          const completion = await openai.createCompletion({
            model: 'text-davinci-003',
            prompt: req.body.text,
            temperature: 0.7,
            top_p: 1,
            max_tokens: 200,
            n: 3
          });
          
          if (completion?.data?.choices) {
            const tweetSuggestions = completion?.data?.choices?.map(item => item.text)
            res.status(200).json({ success: true, message: 'Generated AI tweets', data: tweetSuggestions })
          } else {
            res.status(200).json({ success: true, message: 'No Suggestions for your tweet. Update and try again.', data: [] })
          }
        } catch (e) {
          res.status(200).json({ success: false, message: 'Failed to get response from openai' })
        }
      } else {
        res.status(200).json({ success: true, message: 'Invalid request data' })
      }
      break
    default:
      res.status(200).json({ success: true, message: 'Method not allowed' })
  }
}
