import type { NextApiRequest, NextApiResponse } from 'next'
import { Configuration, OpenAIApi } from 'openai';

const configuration = new Configuration({
  apiKey: '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',
});
const openai = new OpenAIApi(configuration);


type Data = {
  success: boolean,
  message: string,
  data?: (string | undefined)[]
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  switch (req.method){
    case 'POST':
      if (req.body && req.body.text) {
        const content = `suggest best tools for \"${req.body.text}\"`
        try {
          const completion = await openai.createChatCompletion({
            model: 'gpt-3.5-turbo',
            messages: [
              {"role": "system", "content": "You are a helpful assistant that helps me find best tools on internet with website links for requested category"},
              {"role": "user", "content": content}
            ]
            // prompt: req.body.text,
            // temperature: 0.7,
            // top_p: 1,
            // max_tokens: 200,
            // n: 3
          });
          if (completion?.data?.choices) {
            const dataSuggestions: any = completion?.data?.choices?.map(item => item.message)
            res.status(200).json({ success: true, message: 'Suggestions', data: dataSuggestions })
          } else {
            res.status(200).json({ success: true, message: 'No Suggestions', data: [] })
          }
        } catch (e) {
          console.log(e)
          res.status(200).json({ success: false, message: 'Failed to get response from openai' })
        }
      } else {
        res.status(200).json({ success: true, message: 'Invalid request data' })
      }
      break
    default:
      res.status(200).json({ success: true, message: 'Method not allowed' })
  }
}
